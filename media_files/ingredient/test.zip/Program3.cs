﻿using System;
using System.Collections.Generic;


/*
 * 테트리스 게임을 구현 중입니다.
 * 
 * TetrisState 클래스는 테트리스 판에 배치된 블록들의 상태를 나타냅니다.
 * Get, Set, CheckCompleteLine 함수를 구현하기 전에
 * TetrisState 클래스의 내부 변수를 1안과 2안 중 어떤 방식으로 할지 먼저 결정해야 합니다.
 * 
 * 코드의 가독성을 우선시 한다면 1안과 2안 중 어떤 방식을 선택하겠습니까? 그리고 그 이유는 무엇입니까?
 */

//여기 아래에 답변을 적어주세요.
//

class TetrisState
{
	const int TETRIS_SIZE_X = 10;
	const int TETRIS_SIZE_Y = 20;

	bool Get(int x, int y) { throw new NotImplementedException(); }         // x, y 지점에 블록이 있는지 체크하는 함수
	void Set(int x, int y) { throw new NotImplementedException(); }         // x, y 지점에 블록이 있다고 설정하는 함수
	void CheckCompleteLine() { throw new NotImplementedException(); }       // 완성된 줄을 체크하고 제거하는 함수

	//1안)
	bool[,] blocks = new bool[TETRIS_SIZE_X, TETRIS_SIZE_Y];

	//2안)
	List<ushort> lines = new List<ushort>();
}

